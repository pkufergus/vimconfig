# Problems summary


## Expected


## Environment Information
 * OS:
 * Vim version:


## Provide a minimal .vimrc with less than 50 lines (Required!)

```vim
" Your minimal .vimrc
set runtimepath+=~/path/to/unite.nvim/
```


## The reproduce ways from Vim starting (Required!)

 1. foo
 2. bar
 3. baz


## Screen shot (if possible)


## Upload the log messages by `:redir` and `:message`
